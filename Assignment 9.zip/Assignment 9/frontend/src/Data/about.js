import bonie from "../Images/bonie.jpg";
import utsav from "../Images/utsav.jpg";
import rohit from "../Images/rohit.jpg";
import puranjai from "../Images/puranjai.jpg";

const about = [
  {
    _id: "1",
    title: "Utsav Chadha - Software Engineer II",
    image: utsav,
    content:
      "I made a few new friends and introduced myself to a lot of new teachers.",
  },
  {
    _id: "2",
    title: "Rohit Nawani - Software Engineer I",
    image: rohit,
    content: "Learned how to create a server in node JS and my first API",
  },
  {
    _id: "3",
    title: "Puranjai Mendiratta - Co-Founder",
    image: puranjai,
    content: "Finished 2 seasons of Attack on Titan and My Hero academia.",
  },
  {
    _id: 4,
    title: "Bonie Sachdev - Software Engineer II",
    image: bonie,
    content:
      "Made my first App in React JS, feels awesome to learn something new. I aim to be a full stack dev someday",
  },
];

export default about;
